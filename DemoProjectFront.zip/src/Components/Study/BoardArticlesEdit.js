import React from 'react';


function BoardArticlesEdit() {
    return (
        <>
            
        </>
    )
}

export default BoardArticlesEdit;
