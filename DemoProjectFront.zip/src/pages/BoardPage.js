import React from "react";
import BoardComp from "../Components/Study/BoardComp";

const BoardPage = () => {

    return (
        <>
            <BoardComp />
        </>
    )
}

export default BoardPage;