import React from "react";
import MakeBoardComp from "../Components/Study/MakeBoardComp";

const MakeBoardPage = () => {
  return <MakeBoardComp />;
};

export default MakeBoardPage;