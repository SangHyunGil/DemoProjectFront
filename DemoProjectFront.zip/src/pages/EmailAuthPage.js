import React from "react";
import EmailAuth from "../Components/Signup/EmailAuth";

const EmailAuthPage = () => {
  return <EmailAuth />;
};

export default EmailAuthPage;