import React from "react";
import SignUp from "../Components/Signup/SignUp";
const SignUpPage = () => {
  return <SignUp />;
};

export default SignUpPage;