import React from "react";
import SignupComplete from "../Components/Signup/SignupComplete";

const SignUpCompletePage = () => {
  return <SignupComplete />;
};

export default SignUpCompletePage;