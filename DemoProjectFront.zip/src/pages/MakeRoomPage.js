import React from "react";
import MakeRoomComp from "../Components/Study/MakeRoomComp";

const MakeRoomPage = () => {
  return <MakeRoomComp />;
};

export default MakeRoomPage;