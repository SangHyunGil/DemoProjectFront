import React from "react";
import RoomComp from "../Components/Study/RoomComp";

const RoomPage = () => {

    return (
        <div>
            <RoomComp />
        </div>
    )
}

export default RoomPage;